package com.lesfurets.jenkins.unit.declarative.kubernetes

import com.lesfurets.jenkins.unit.declarative.GenericPipelineDeclaration


class PodTemplateDeclaration extends GenericPipelineDeclaration {
}
