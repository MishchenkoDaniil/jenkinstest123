// file: vars/oneArg.groovy
def call(arg) {
    echo arg ? "Is not null" : "Is null"
}
