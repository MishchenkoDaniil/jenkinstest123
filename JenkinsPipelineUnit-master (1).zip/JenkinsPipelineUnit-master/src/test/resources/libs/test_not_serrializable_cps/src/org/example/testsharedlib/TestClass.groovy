package org.example.testsharedlib

public class TestClass {
  String test1() {
    return 'ok'
  }
}
