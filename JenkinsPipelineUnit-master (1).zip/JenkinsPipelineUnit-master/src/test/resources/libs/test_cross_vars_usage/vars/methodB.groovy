def call() {
   echo "I'm B"
   echo "env = $env"
}
