def call() {
   echo "I'm A"
   echo "env = $env"
}
