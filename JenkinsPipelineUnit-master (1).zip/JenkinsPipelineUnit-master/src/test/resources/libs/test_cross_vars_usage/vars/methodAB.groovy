def call() {
   methodA()
   methodB()
   echo "env = $env"
}
