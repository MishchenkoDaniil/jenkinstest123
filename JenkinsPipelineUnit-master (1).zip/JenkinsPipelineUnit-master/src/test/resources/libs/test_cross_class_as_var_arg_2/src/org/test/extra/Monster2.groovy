package org.test.extra

class Monster2 {
    String moniker
    
    Monster2(String m) {
        moniker = m
    }
}
