import org.test.extra.Monster2

void call(Monster2 m2) {
    echo "$m2.moniker all by itself is frightening"
}
