import org.test.Monster1
import org.test.extra.Monster2

void call(Monster1 m1) {
    final m2 = new Monster2("Frankenstein's Monster")
    monster2 m2
    echo "$m1.moniker and $m2.moniker make quite a scary team"
}
