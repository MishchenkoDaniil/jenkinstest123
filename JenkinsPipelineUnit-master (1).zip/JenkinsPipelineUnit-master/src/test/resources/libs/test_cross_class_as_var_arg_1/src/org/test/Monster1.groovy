package org.test

class Monster1 {
    String moniker

    Monster1(String m) {
      moniker = m
    }
}
